<template>
  <div id="app">
    <h1>페이지3</h1>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

