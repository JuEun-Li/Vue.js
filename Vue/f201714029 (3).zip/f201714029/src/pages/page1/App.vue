<template>
  <div id="app">
    <h1>페이지1</h1>
  </div>
</template>

<script>
import Num1 from "./Num1.vue";

export default {
  name: "App"
};
</script>

<style scoped>
div#app {
  padding: 0 30px 30px 30px;
  margin: 30px auto;
  max-width: 400px;
  border: 1px solid #ccc;
  box-shadow: 3px 3px 3px #aaa;
}
</style>

