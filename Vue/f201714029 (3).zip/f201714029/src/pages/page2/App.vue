<template>
  <div id="app">
    <h1>페이지2</h1>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

